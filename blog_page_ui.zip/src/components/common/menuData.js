export const menuData = [
    {
        label: "Main Menu",
        items: [
            {
                name: "Dashboard", route: "",
            },

        ]
    },
];
