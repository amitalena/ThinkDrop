import React from 'react'
import BlogList from '../blogs/BlogList'

const Dashboard = () => {
    return (
        <>
            <BlogList />
        </>
    )
}

export default Dashboard